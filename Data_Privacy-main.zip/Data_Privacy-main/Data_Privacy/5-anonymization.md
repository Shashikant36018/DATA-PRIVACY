# Practical 5: Anonymization Techniques for Data Privacy

## Aim

To understand different data anonymization techniques and study how personal information can be transformed to protect individual privacy while still allowing the data to be used for analysis.

## Introduction

**Data anonymization** is the process of modifying or removing personally identifiable information (PII) so that individuals cannot be easily identified from the resulting dataset.

Anonymization is commonly used when organizations need to analyze or share data while reducing privacy risks.

For example, instead of storing:

```text
Name: Rahul Sharma
Age: 21
City: Delhi
Email: rahul@example.com
```

The data might be transformed to:

```text
Name: [REDACTED]
Age: 20-25
City: North India
Email: [REDACTED]
```

However, anonymization does not automatically guarantee complete privacy. The possibility of re-identification must be considered, especially when multiple datasets can be combined.

## Major Anonymization Techniques

### 1. Data Masking / Suppression

Suppression involves completely removing or hiding specific data attributes (like names, phone numbers, or exact addresses) from the dataset.

- **Example:** Replacing a 16-digit credit card number with `XXXX-XXXX-XXXX-1234`.
- **Use Case:** Removing direct identifiers before sharing research data or displaying payment details on a screen.

### 2. Generalization

Generalization reduces the precision of the data while maintaining its broader analytical value. It replaces exact values with categories or ranges.

- **Example:** Replacing the exact age "21" with the range "20-25", or replacing the specific city "Delhi" with "North India".
- **Use Case:** Demographic analysis and marketing research where exact individual details are not strictly necessary.
  ### 3. Pseudonymization

Pseudonymization replaces private identifiers with fake identifiers or pseudonyms (e.g., tokens or reference numbers). Unlike true anonymization, pseudonymization is reversible if you possess the secure mapping key.

- **Example:** Replacing "Rahul Sharma" with a unique system ID string like `User_9942`.
- **Use Case:** Internal database analytics where data can be linked back to the user only by authorized personnel with access to the key.

### 4. Data Perturbation (Noise Addition)

This technique modifies the original data slightly by adding random statistical noise. The overall statistical trends in the dataset remain the same, but individual records are altered.

- **Example:** Altering a user's exact login timestamp by +/- 15 minutes.
- **Use Case:** Machine learning model training and the publication of census data.

## Advanced Privacy Models

To mathematically measure and enforce how well data is anonymized, several models are used:

- **k-Anonymity:** Ensures that any given individual's data cannot be distinguished from at least *k-1* other individuals in the dataset. This is achieved by grouping quasi-identifiers (like Age, Gender, and ZIP code).
- **l-Diversity:** An extension of k-anonymity that ensures sensitive attributes (like medical diagnoses) within the *k* group have at least *l* distinct values, preventing attackers from guessing a specific attribute.
- **Differential Privacy:** Adds calculated statistical noise to query results, ensuring that the inclusion or exclusion of a single individual's record does not significantly affect the final output.

## Example: LeetCode

For an online educational and coding platform like LeetCode, data anonymization is vital for safely sharing platform analytics:
- **Leaderboards & Contests:** Displaying pseudonyms (usernames) instead of real legal names or emails.
- **Performance Analytics:** Aggregating problem-solving times (generalization) to show average user performance without exposing the exact activity logs of individual users.
- **Bug Reports & Telemetry:** Removing raw IP addresses (suppression) when analyzing server traffic or system crashes to protect user locations.
  ## Privacy vs. Utility Trade-off

The core challenge of anonymization is the inverse relationship between data privacy and data utility:

- **High Anonymization:** Data is extremely secure, but highly generalized (e.g., removing ages and locations entirely). The data loses much of its analytical value.
- **High Utility:** Data retains exact values (e.g., exact age, precise location) for highly accurate analytics, but the risk of re-identifying individuals becomes dangerously high.

## Re-identification Risks

Even anonymized data can be vulnerable to privacy attacks:
1. **Linkage Attacks:** An attacker cross-references an anonymized dataset with a public dataset (like a voter registry) using shared attributes (quasi-identifiers) to successfully re-identify individuals.
2. **Background Knowledge Attacks:** An attacker uses their personal knowledge about an individual in the dataset to deduce which exact record belongs to them.

## Recommended Security Practices

- Remove direct identifiers (names, emails, SSNs) immediately during data collection or ingestion.
- Generalize quasi-identifiers (ZIP codes, exact birthdates) to achieve a baseline of *k*-anonymity.
- Treat IP addresses and MAC addresses as Personally Identifiable Information (PII) and mask them.
- Regularly perform re-identification risk assessments before publishing or sharing datasets.
- Use Differential Privacy for public-facing data queries where applicable.

## Conclusion

Data anonymization is essential for balancing the need for data analysis with the fundamental right to individual privacy. By employing techniques like suppression, generalization, pseudonymization, and leveraging frameworks like k-anonymity, organizations can safely extract value from data. However, practitioners must remain aware of re-identification risks and continuously adjust the privacy-utility trade-off.

**Overall Importance:** High

## References

- NIST Privacy Framework: https://www.nist.gov/privacy-framework
- NIST De-Identification Guidelines: https://www.nist.gov/publications/de-identification-personal-information
- LeetCode Privacy Policy: https://leetcode.com/privacy/
- LeetCode Terms of Service: https://leetcode.com/terms/
